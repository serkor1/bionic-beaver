#' @keywords internal
#' @import grid
#' @aliases NULL
#'
#' @seealso [gtable()] for an overview of the class and construction
#'
"_PACKAGE"
