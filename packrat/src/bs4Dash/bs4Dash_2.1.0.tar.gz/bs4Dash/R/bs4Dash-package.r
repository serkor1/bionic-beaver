#' bs4Dash
#'
#' @name bs4Dash
#' @docType package
#' @importFrom lifecycle deprecated
#' @noRd
"_PACKAGE"