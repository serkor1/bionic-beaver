library(testthat)
library(fresh)

test_check("fresh")
