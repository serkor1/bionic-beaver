
test_that("use_googlefont works", {
  expect_is(use_googlefont("Saira Stencil One"), "html_dependency")
})
