
test_that("rd_col works", {
  expect_is(rd_col("#000"), "character")
})
