# app template works with runTests: all

    Code
      out
    Output
      Shiny App Test Results
      * Failure
        - shinyAppTemplate-all/tests/testthat.R

# app template works with runTests: app_tests

    Code
      out
    Output
      Shiny App Test Results
      * Failure
        - shinyAppTemplate-app_tests/tests/testthat.R

# app template works with runTests: app_module_tests

    Code
      out
    Output
      Shiny App Test Results
      * Failure
        - shinyAppTemplate-app_module_tests/tests/testthat.R

# app template works with runTests: app_rdir_tests

    Code
      out
    Output
      Shiny App Test Results
      * Failure
        - shinyAppTemplate-app_rdir_tests/tests/testthat.R

# app template works with runTests: app_module_rdir_tests

    Code
      out
    Output
      Shiny App Test Results
      * Failure
        - shinyAppTemplate-app_module_rdir_tests/tests/testthat.R

# app template works with runTests: app_shinytest_testthat

    Code
      out
    Output
      Shiny App Test Results
      * Failure
        - shinyAppTemplate-app_shinytest_testthat/tests/testthat.R

