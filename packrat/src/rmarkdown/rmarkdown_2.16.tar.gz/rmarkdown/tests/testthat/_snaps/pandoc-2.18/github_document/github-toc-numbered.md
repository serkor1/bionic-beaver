
-   <a href="#1-section" id="toc-1-section">1 Section</a>
-   <a href="#2-header" id="toc-2-header">2 Header</a>

# 1 Section

Sentence.

# 2 Header

Sentence
