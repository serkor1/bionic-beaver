library(shiny)
# devtools::load_all('/Users/pwan44/Documents/Tychobra/shinyFeedback')

# polished::set_config_env()
#
# config <- config::get(file = "config.yml")
#
# conn <- tychobratools::db_connect(config$db)
#
# global_sessions_config(
#   conn = conn,
#   app_name = config$app_name,
#   firebase_project_id = config$firebase$projectId#,
#   # admin_mode = TRUE
# )

