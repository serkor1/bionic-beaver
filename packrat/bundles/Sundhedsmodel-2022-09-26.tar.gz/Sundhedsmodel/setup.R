# script: Setup Script
# date: Mon Sep 26 10:52:29 2022
# author: Serkan Korkmaz
# objective: Run this script to setup 
# necessary packages.

