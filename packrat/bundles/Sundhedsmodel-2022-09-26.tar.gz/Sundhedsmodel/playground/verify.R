# script: Verify ID
# objective: Verify calculations in Spread and Flavor
# date: 2022-08-22
# author: Serkan Korkmaz

# Clear Workspace and Setup; ####
rm(list = ls()); gc()

# packages;

library(stringr)
library(shiny)
library(bs4Dash)
library(shinyjs)
library(shinyWidgets)
library(data.table)
library(plotly)
library(DT)
library(fresh)
library(purrr)
library(rhandsontable)
library(readODS)
library(shinycssloaders)
library(shinyFeedback)
library(waiter)
library(formattable)

# Developper Mode;
developper_mode = FALSE

# Setup script; ####
# 
# If the parameters have not been loaded
# execute the scripts
check_parameter <- list.files(
  path = "input/parameters/",
  recursive = TRUE
) %>% length()

if (check_parameter == 0) {
  
  message("Running Price-parameter scripts!")
  
  map(
    list.files(
      path = "r/setup/",
      full.names = TRUE
    ),
    source,
    encoding = 'UTF-8'
  )
  
}




# Load Modules and Utilities; #####
list.files(
  path = "r",
  recursive = TRUE,
  full.names = TRUE
) %>% map(
  source,
  encoding = 'UTF-8'
  
)


# preload data;
set.seed(1903)
system.time(
  data_list <- preload_data(
    developper_mode = developper_mode
  )
)


# version;
version <- c("v0.3.1")

# version;
version <- c("v0.3.1")




# Preloading Options; #####

load_parameters <- .gen_option(
  data_list = data_list
)


chars      <- load_parameters$chars
assignment <- load_parameters$assignment
outcome    <- load_parameters$outcome
lookup     <- .gen_lookup(data_list)




# split data; ####

model1_data <- data_list[[1]]
model2_data <- data_list[[2]]

model1_parameters <- dev_load_char(
  data_list,
  'model1'
)

model2_parameters <- dev_load_char(
  data_list,
  'model2'
)

model1_data$medication$assignment %>% unique()

model1 <-  model1_data %>% grind(
  intervention = "Diabetes II_Uden Komplikationer",
  #control      = 'Psykiske Lidelser_Moderat',
  allocators = c('Primær Sektor_Almen Praksis'),
  #chars = c('køn_Kvinde'),
  #chars = c('køn_Kvinde', 'arbejdsmarked_Inaktiv'),
  #chars = c('køn_Mand'),# 'køn_Kvinde', 'arbejdsmarked_Inaktiv', 'uddannelse_Faglært'),
  do_incidence = TRUE
  # allocators = c('Psykiatrien_Ambulant', 'Somatikken_Indlæggelse', 'Overførsel_Førtidspension')
  # allocators = model1_parameters$outcome
) 






model1 %>% spread()



# grinded; grouped
grinded <- model1$primary_care


grinded <- grinded[
  !(assignment %chin% 'matching')  & outcome_type %chin% 'qty'
]


grinded[
  ,
  .(
    # This is Correct
    outcome1 = (sum(outcome * weight, na.rm = TRUE)) / sum(weight, na.rm = TRUE),
    outcome2 = (sum(outcome * weight, na.rm = TRUE))
  )
  ,
  by = .(
    x,
    assignment,
    allocator
  )
]




# Manual; grouped
data <- fread(
  input = 'input/data/model1/somatic_care.csv'
)



data <- data[!(assignment %chin% 'matching') & allocator %chin% c('somatikken_Ambulant')
]


# This is the correct way to do it
data <- data[
  køn %chin% c('Kvinde') & assignment %chin% "Psykiske Lidelser_Svær"
  ,
  .(
    qty = (sum(qty * weight, na.rm = TRUE)) / sum(weight, na.rm = TRUE)
  )
  ,
  by = .(
    assignment,
    type,
    year
  )
]



dcast(
  data,
  formula = year + assignment~ type,
  value.var = 'qty'
)
