rm(list = ls()); gc()

library(data.table)




data <- fread(
  input = 'input/data/model1/somatic_care.csv'
  )



data <- data[
  year == 5 & !(assignment %chin% 'matching') & allocator %chin% c('somatikken_Ambulant')
]


# This is the correct way to do it
data <- data[
  køn %chin% c('Kvinde')
  ,
  .(
    qty = (sum(qty * weight, na.rm = TRUE)) / sum(weight, na.rm = TRUE)
  )
  ,
  by = .(
    assignment,
    type
  )
]



dcast(
  data,
  formula = assignment ~ type,
  value.var = 'qty'
)




somatic_care <- model1$somatic_care


somatic_care <- somatic_care[
  x == 5  & !(assignment %chin% 'matching') & allocator %chin% c('somatikken_Ambulant') & outcome_type %chin% 'qty'
]


somatic_care[
  ,
  .(
    # This is Correct
    outcome1 = (sum(outcome * weight, na.rm = TRUE)) / sum(weight, na.rm = TRUE),
    outcome2 = (sum(outcome * weight, na.rm = TRUE))
  )
  ,
  by = .(
    type,
    assignment
  )
]
