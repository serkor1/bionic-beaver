# Clear Workspace and Setup; ####
rm(list = ls()); gc()

# packages;

library(stringr)
library(shiny)
library(bs4Dash)
library(shinyjs)
library(shinyWidgets)
library(data.table)
library(plotly)
library(DT)
library(fresh)
library(purrr)
library(rhandsontable)
library(readODS)
library(shinycssloaders)
library(shinyFeedback)
library(waiter)
library(formattable)

# Developper Mode;
developper_mode = FALSE

# Setup script; ####
# 
# If the parameters have not been loaded
# execute the scripts
check_parameter <- list.files(
  path = "input/parameters/",
  recursive = TRUE
) %>% length()

if (check_parameter == 0) {
  
  message("Running Price-parameter scripts!")
  
  map(
    list.files(
      path = "r/setup/",
      full.names = TRUE
    ),
    source,
    encoding = 'UTF-8'
  )
  
}




# Load Modules and Utilities; #####
list.files(
  path = "r",
  recursive = TRUE,
  full.names = TRUE
) %>% map(
  source,
  encoding = 'UTF-8'
  
)


# preload data;
set.seed(1903)
system.time(
  data_list <- preload_data(
    developper_mode = developper_mode
  )
)


# version;
version <- c("v0.3.1")



# Preloading Options; #####

load_parameters <- .gen_option(
  data_list = data_list
)


chars      <- load_parameters$chars
assignment <- load_parameters$assignment
outcome    <- load_parameters$outcome
lookup     <- .gen_lookup(data_list)



model1_data <- data_list[[1]]


intervention <- sample(unlist(assignment[[1]]),1)
allocators <- sample(unlist(outcome[[1]]),1)

# model 1 test; 
model1 <-  model1_data %>% grind(
  intervention = 'Cancer_Prostata',
  control      = 'Diabetes I_Uden Komplikationer',
  allocators = 'Lægemiddelforbrug_Personlige Udgifter',
  alternate = TRUE,
  # allocators = c('Psykiatrien_Ambulant', 'Somatikken_Indlæggelse', 'Overførsel_Førtidspension')
  # allocators = model1_parameters$outcome
) %>% spread() %>% flavor(effect = rep(0.50,5))












.model1_performance <- function(
    data_list
) {
  
  
  data_list <- map(
    data_list,
    .f = function(element) {
      
      
      
      
      
    }
  )
  
  
  
}