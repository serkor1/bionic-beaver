# script: This 
# objective: 
# date: 2022-08-22
# author: Serkan Korkmaz
# script: Verify ID
# objective: Verify calculations in Spread and Flavor
# date: 2022-08-22
# author: Serkan Korkmaz

# Clear Workspace and Setup; ####
rm(list = ls()); gc()

# packages;

library(stringr)
library(shiny)
library(bs4Dash)
library(shinyjs)
library(shinyWidgets)
library(data.table)
library(plotly)
library(DT)
library(fresh)
library(purrr)
library(rhandsontable)
library(readODS)
library(shinycssloaders)
library(shinyFeedback)
library(waiter)
library(formattable)

# Developper Mode;
developper_mode = FALSE

# Setup script; ####
# 
# If the parameters have not been loaded
# execute the scripts
check_parameter <- list.files(
  path = "input/parameters/",
  recursive = TRUE
) %>% length()

if (check_parameter == 0) {
  
  message("Running Price-parameter scripts!")
  
  map(
    list.files(
      path = "r/setup/",
      full.names = TRUE
    ),
    source,
    encoding = 'UTF-8'
  )
  
}




# Load Modules and Utilities; #####
list.files(
  path = "r",
  recursive = TRUE,
  full.names = TRUE
) %>% map(
  source,
  encoding = 'UTF-8'
  
)


# preload data;
set.seed(1903)
system.time(
  data_list <- preload_data(
    developper_mode = developper_mode
  )
)


# version;
version <- c("v0.3.1")

# version;
version <- c("v0.3.1")




# Preloading Options; #####

load_parameters <- .gen_option(
  data_list = data_list
)


chars      <- load_parameters$chars
assignment <- load_parameters$assignment
outcome    <- load_parameters$outcome
lookup     <- .gen_lookup(data_list)







ids <- .extract_id(
  lookup = lookup[[1]]$transfers,
  values = c('arbejdsmarked_Inaktiv', 'køn_Mand')
)



data_list[[1]]$transfers[
  id %in% ids
]




# Verify Data;
transfer_wide <- fread(
  'input/data/model1/transfers.csv'
)

transfer_wide <- transfer_wide[
  type == 0 & assignment %chin% c('Cancer_Prostata', 'Diabetes I_Uden Komplikationer') & køn == 'Mand' & arbejdsmarked == 'Inaktiv'
]


transfer_wide[
  ,
  .(
    total_n = sum(total_n, na.rm = TRUE),
    total_N = na.omit(unique(total_N)),
    average = mean(qty, na.rm = TRUE)
  )
  ,
  by = .(
    allocator,
    assignment,
    year
  )
][
  allocator %chin% 'Overførsel_Midlertidig Overførselsindkomst'
]






data_list[[1]] %>% grind(
  intervention = 'Cancer_Prostata',
  control      = 'Diabetes I_Uden Komplikationer',
  chars = c('køn_Mand', 'arbejdsmarked_Inaktiv'),
  allocators = c('Overførsel_Midlertidig Overførselsindkomst')
) %>% spread()
