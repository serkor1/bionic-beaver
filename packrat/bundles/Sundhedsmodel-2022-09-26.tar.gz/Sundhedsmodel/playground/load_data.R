# script: load data
# objective: Load the data
# date: 2022-09-18
# author: Serkan Korkmaz
# Clear Workspace and Setup; ####
rm(list = ls()); gc()

# packages;

library(stringr)
library(shiny)
library(bs4Dash)
library(shinyjs)
library(shinyWidgets)
library(data.table)
library(plotly)
library(DT)
library(fresh)
library(purrr)
library(rhandsontable)
library(readODS)
library(shinycssloaders)
library(shinyFeedback)
library(waiter)
library(formattable)

# Developper Mode;
developper_mode = FALSE

# Setup script; ####
# 
# If the parameters have not been loaded
# execute the scripts
check_parameter <- list.files(
  path = "input/parameters/",
  recursive = TRUE
) %>% length()

if (check_parameter == 0) {
  
  message("Running Price-parameter scripts!")
  
  map(
    list.files(
      path = "r/setup/",
      full.names = TRUE
    ),
    source,
    encoding = 'UTF-8'
  )
  
}




# Load Modules and Utilities; #####
list.files(
  path = "r",
  recursive = TRUE,
  full.names = TRUE
) %>% map(
  source,
  encoding = 'UTF-8'
  
)


# preload data;
set.seed(1903)
system.time(
  data_list <- preload_data(
    developper_mode = developper_mode
  )
)

