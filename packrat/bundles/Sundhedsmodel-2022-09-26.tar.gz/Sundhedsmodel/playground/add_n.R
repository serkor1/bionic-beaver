# adding counters




mtcars_dt <- as.data.table(
  mtcars
)

idx <- which(
  sapply(
    colnames(mtcars),
    function(x) {
      
      str_detect(
        x, pattern = 'mpg|cyl|vs|am|gear'
      )
      
    }
  )
)

data <- mtcars_dt[
  ,
  ..idx
  ,
]


data[
  ,
  id := .GRP
  ,
  by = .(
    cyl,
    vs,
    am,
    gear
  )
]


lookup_table <- unique(
  data[
    ,
    .(
      cyl,
      vs,
      am,
      gear,
      id
    )
    ,
  ]
)






data <- melt(
  data,
  id.vars = c('id','mpg'),
  measure.vars = c('cyl','vs','am','gear'),
)






data_list[[1]]$medication[id %in% c(9,11,15)]

test <- lookup[[1]]$medication[id %in% c(9,11,15)]

