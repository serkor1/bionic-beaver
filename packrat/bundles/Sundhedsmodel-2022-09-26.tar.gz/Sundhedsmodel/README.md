[![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green.svg)](https://GitHub.com/Naereen/StrapDown.js/graphs/commit-activity)
![Maintainer](https://img.shields.io/badge/Maintainer-Serkan_Korkmaz-blue)

## Beregner til Investeringer i Sundhed

Modellen er udviklet af VIVE Sundhed og VIVE Effekt. Modellen er finansieret af Lægemiddelindustriforeningen.


### Forslag til forbedringer

Alle forslag skal uploades til `development`-branch, og skrives på engelsk. Forslag der indebærer optimeringer til
databehandling som ikke er skrevet i `data.table` afvises automatisk.

### Fejl og mangler

Hvis der er fejl, og mangler i modellen kan du oprette en ticket her. 




